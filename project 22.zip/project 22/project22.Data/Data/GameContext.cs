﻿using Microsoft.EntityFrameworkCore;
using project22.Data.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project22.Data.Data
{
    public class GameContext : DbContext
    {
        public DbSet<Player> Players { get; set; }
        public DbSet<Faction> Factions { get; set; }
        public DbSet<PlayerFaction> PlayerFactions { get; set; }
        public DbSet<Building> Buildings { get; set; }
        public DbSet<PlayerBuilding> PlayerBuildings { get; set; }
        public DbSet<Unit> Units { get; set; }
        public DbSet<PlayerUnit> PlayerUnits { get; set; }
        public DbSet<Resource> Resources { get; set; }
        public DbSet<PlayerResource> PlayerResources { get; set; }
        public DbSet<Battle> Battles { get; set; }
        public DbSet<BattleUnit> BattleUnits { get; set; }
        public DbSet<Map> Maps { get; set; }
        public DbSet<PlayerLocation> PlayerLocations { get; set; }
        public DbSet<Technology> Technologies { get; set; }
        public DbSet<PlayerTechnology> PlayerTechnologies { get; set; }

        public GameContext(DbContextOptions<GameContext> options) : base(options) { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Composite or complex configurations if needed
            modelBuilder.Entity<PlayerResource>()
                .HasIndex(pr => new { pr.PlayerId, pr.ResourceId })
                .IsUnique();

            modelBuilder.Entity<PlayerTechnology>()
                .HasIndex(pt => new { pt.PlayerId, pt.TechnologyId })
                .IsUnique();

            modelBuilder.Entity<PlayerFaction>()
                .HasIndex(pf => new { pf.PlayerId, pf.FactionId })
                .IsUnique();

            modelBuilder.Entity<Battle>()
                .HasOne(b => b.Attacker)
                .WithMany()
                .HasForeignKey(b => b.AttackerId)
                .OnDelete(DeleteBehavior.Restrict); // To avoid circular cascade

            modelBuilder.Entity<Battle>()
                .HasOne(b => b.Defender)
                .WithMany()
                .HasForeignKey(b => b.DefenderId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Faction>().HasData(
    new Faction { Id = 1, Name = "Humans", Description = "Balanced race with strong economy." },
    new Faction { Id = 2, Name = "Orcs", Description = "Strong melee units, weak defenses." }
);

            modelBuilder.Entity<Building>().HasData(
                new Building { Id = 1, Name = "Barracks", Description = "Trains infantry.", BuildTime = 60, FactionId = 1 },
                new Building { Id = 2, Name = "Farm", Description = "Produces food.", BuildTime = 30, FactionId = 1 }
            );

            modelBuilder.Entity<Unit>().HasData(
                new Unit { Id = 1, Name = "Swordsman", AttackPower = 10, DefensePower = 5, TrainingTime = 45, FactionId = 1 },
                new Unit { Id = 2, Name = "Archer", AttackPower = 7, DefensePower = 3, TrainingTime = 30, FactionId = 1 }
            );

            modelBuilder.Entity<Resource>().HasData(
                new Resource { Id = 1, Name = "Gold", Description = "Used for building and training." },
                new Resource { Id = 2, Name = "Food", Description = "Required for units to survive." }
            );

            modelBuilder.Entity<Technology>().HasData(
                new Technology { Id = 1, Name = "Advanced Metallurgy", Description = "Increases attack by 10%", ResearchTime = 120 },
                new Technology { Id = 2, Name = "Efficient Farming", Description = "Increases food production by 20%", ResearchTime = 90 }
            );

            modelBuilder.Entity<Map>().HasData(
                new Map { Id = 1, Name = "Valley of Kings", SizeX = 100, SizeY = 100, Description = "A balanced map with hills and forests." }
            );

        }
    }
}
