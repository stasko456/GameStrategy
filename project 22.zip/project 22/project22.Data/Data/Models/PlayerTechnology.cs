﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project22.Data.Data.Models
{
    public class PlayerTechnology
    {
        public int Id { get; set; }
        public int PlayerId { get; set; }
        public Player Player { get; set; }
        public int TechnologyId { get; set; }
        public Technology Technology { get; set; }
        public bool IsResearched { get; set; }
        public DateTime? ResearchedAt { get; set; }
    }
}
