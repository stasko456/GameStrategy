﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project22.Data.Data.Models
{
    public class PlayerBuilding
    {
        public int Id { get; set; }
        public int PlayerId { get; set; }
        public Player Player { get; set; }
        public int BuildingId { get; set; }
        public Building Building { get; set; }
        public int Level { get; set; }
        public DateTime BuiltAt { get; set; }
    }
}
