﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project22.Data.Data.Models
{
    public class Technology
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int ResearchTime { get; set; }

        public ICollection<PlayerTechnology> PlayerTechnologies { get; set; }
    }
}
