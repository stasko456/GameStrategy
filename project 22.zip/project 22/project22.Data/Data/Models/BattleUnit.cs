﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project22.Data.Data.Models
{
    public class BattleUnit
    {
        public int Id { get; set; }
        public int BattleId { get; set; }
        public Battle Battle { get; set; }
        public int UnitId { get; set; }
        public Unit Unit { get; set; }
        public int PlayerId { get; set; }
        public Player Player { get; set; }
        public int Quantity { get; set; }
    }
}
