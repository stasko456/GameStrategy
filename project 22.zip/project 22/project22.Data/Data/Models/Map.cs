﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project22.Data.Data.Models
{
    public class Map
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int SizeX { get; set; }
        public int SizeY { get; set; }
        public string Description { get; set; }

        public ICollection<PlayerLocation> PlayerLocations { get; set; }
    }
}
