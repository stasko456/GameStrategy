﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project22.Data.Data.Models
{
    public class Unit
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int AttackPower { get; set; }
        public int DefensePower { get; set; }
        public int TrainingTime { get; set; }
        public int FactionId { get; set; }
        public Faction Faction { get; set; }

        public ICollection<PlayerUnit> PlayerUnits { get; set; }
        public ICollection<BattleUnit> BattleUnits { get; set; }
    }
}
