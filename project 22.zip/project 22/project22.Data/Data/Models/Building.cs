﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project22.Data.Data.Models
{
    public class Building
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int BuildTime { get; set; }
        public int FactionId { get; set; }
        public Faction Faction { get; set; }

        public ICollection<PlayerBuilding> PlayerBuildings { get; set; }
    }
}
