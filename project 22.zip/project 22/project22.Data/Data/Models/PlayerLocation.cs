﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project22.Data.Data.Models
{
    public class PlayerLocation
    {
        public int Id { get; set; }
        public int PlayerId { get; set; }
        public Player Player { get; set; }
        public int MapId { get; set; }
        public Map Map { get; set; }
        public int X { get; set; }
        public int Y { get; set; }
    }
}
