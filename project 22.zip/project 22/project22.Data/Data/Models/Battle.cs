﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project22.Data.Data.Models
{
    public class Battle
    {
        public int Id { get; set; }
        public int AttackerId { get; set; }
        public Player Attacker { get; set; }
        public int DefenderId { get; set; }
        public Player Defender { get; set; }
        public DateTime StartedAt { get; set; }
        public DateTime? EndedAt { get; set; }
        public BattleResult Result { get; set; }

        public ICollection<BattleUnit> BattleUnits { get; set; }
    }

    public enum BattleResult
    {
        AttackerWin,
        DefenderWin,
        Draw
    }
}
