﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project22.Data.Data.Models
{
    public class Player
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }
        public DateTime CreatedAt { get; set; }

        public ICollection<PlayerFaction> PlayerFactions { get; set; }
        public ICollection<PlayerBuilding> PlayerBuildings { get; set; }
        public ICollection<PlayerUnit> PlayerUnits { get; set; }
        public ICollection<PlayerResource> PlayerResources { get; set; }
        public ICollection<PlayerTechnology> PlayerTechnologies { get; set; }
        public ICollection<Battle> BattlesAsAttacker { get; set; }
        public ICollection<Battle> BattlesAsDefender { get; set; }
        public ICollection<PlayerLocation> PlayerLocations { get; set; }
    }
}
