﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using project22.Data.Data.Models;

namespace project22.Core
{
    public class ReportsController
    {
        private readonly GameContext _context;

        // 1. Всички играчи с техните ресурси
        public async Task<IActionResult> PlayersWithResources()
        {
            var players = await _context.Players
                .Include(p => p.PlayerResources)
                    .ThenInclude(pr => pr.Resource)
                .ToListAsync();

            return View(players); // Очаква се View: Views/Reports/PlayersWithResources.cshtml
        }

        // 2. Последните 5 битки по дата на начало (StartedAt)
        public async Task<IActionResult> Last5Battles()
        {
            var battles = await _context.Battles
                .Include(b => b.Attacker)
                .Include(b => b.Defender)
                .OrderByDescending(b => b.StartedAt)
                .Take(5)
                .ToListAsync();

            return View(battles); // Очаква се View: Views/Reports/Last5Battles.cshtml
        }

        // 3. Сгради и единици за фракция "Humans"
        public async Task<IActionResult> FactionAssets()
        {
            var faction = await _context.Factions
                .FirstOrDefaultAsync(f => f.Name == "Humans");

            if (faction == null)
            {
                return NotFound("Faction 'Humans' not found.");
            }

            var buildings = await _context.Buildings
                .Where(b => b.FactionId == faction.Id)
                .ToListAsync();

            var units = await _context.Units
                .Where(u => u.FactionId == faction.Id)
                .ToListAsync();

            var result = new FactionAssetsViewModel
            {
                FactionName = faction.Name,
                Buildings = buildings,
                Units = units
            };

            return View(result); // Очаква се View: Views/Reports/FactionAssets.cshtml
        }
    }
}
