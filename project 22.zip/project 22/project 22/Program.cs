﻿namespace project_22
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
